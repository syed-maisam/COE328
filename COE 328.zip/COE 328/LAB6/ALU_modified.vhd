LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.NUMERIC_STD.ALL;

ENTITY ALU_modified IS
PORT (Clock : IN STD_LOGIC ;
A ,B : IN UNSIGNED(7 DOWNTO 0);
Student_id: IN UNSIGNED(3 DOWNTO 0);
OP: IN UNSIGNED(15 DOWNTO 0);
Neg: OUT STD_LOGIC;
R1: OUT UNSIGNED(3 DOWNTO 0);--first 4bits of 8bits Result
R2: OUT UNSIGNED(3 DOWNTO 0));--later 4bits of 8bits Result
END ALU_modified;

ARCHITECTURE Behavior OF ALU_modified IS
SIGNAL Reg1, Reg2, Result: UNSIGNED(7 DOWNTO 0) := (OTHERS => '0');
SIGNAL Reg4: UNSIGNED(0 TO 7);

BEGIN
	Reg1 <= A;
	Reg2 <= B;
	
	PROCESS (Clock,OP,A,B)
	BEGIN
	IF (rising_edge(Clock)) THEN
		CASE OP IS
			WHEN "0000000000000001" => --function 1
				neg <= '0';
				Result <= Reg1 + 2;
			WHEN "0000000000000010" => --function 2
				neg <= '0';
				Result <= shift_right((Reg2),2);
			WHEN "0000000000000100" => --function 3
				neg <= '0';
				Result <= shift_right((Reg1),4);
			WHEN "0000000000001000"  => -- function 4
				if (Reg1 < Reg2) then
					Result <= (Reg1);
				else
					Result <= (Reg2);
				end if;
				neg <= '0';
			WHEN "0000000000010000" =>--Function 5 
				neg <= '0';
				Result <= Reg1(5)&Reg1(4)&Reg1(3)&Reg1(2)&Reg1(1)&Reg1(0)&Reg1(7)&Reg1(6);
			WHEN "0000000000100000" =>--Function 6 
				neg <= '0';
				Result <= Reg2 xor "11111111";
			WHEN "0000000001000000" =>--Function 7 
				neg <= '0';
				Result <= (Reg1 XOR Reg2);
			WHEN "0000000010000000" =>--Function 8 
				neg <= '0';
				Result <= (Reg1 + Reg2) - 4;
			WHEN "0000000100000000" =>--Function 9 
				neg <= '0';
				Result <= "11111111";
			WHEN OTHERS =>-- Don't care
			END CASE;
		END IF;
	END PROCESS;
	
	R1 <= Result(3 DOWNTO 0);
	R2 <= Result(7 DOWNTO 4);

END Behavior;