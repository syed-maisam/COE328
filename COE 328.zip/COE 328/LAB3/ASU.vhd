library ieee ;
use ieee.std_logic_1164.all ;
use ieee.std_logic_unsigned.all ;

entity ASU is
	port (Cin              : in std_logic;
           X, Y           : in std_logic_vector(3 downto 0);
           S              : out std_logic_vector(3 downto 0);
           Cout, Neg      : out std_logic);
end ASU;

architecture Behavior of ASU is

signal Sum : std_logic_vector(4 downto 0);

	begin
		PROCESS (X, Y, CIN)
		BEGIN
			IF CIN = '0' THEN
			Sum <= ('0' & X) + ('0' & Y);
			S<= Sum (3 DOWNTO 0);
			Cout<=Sum(4);
			
	ELSE
		sum <= ('0' & X) - ('0' & Y);
			IF (X>= Y) THEN
			S<= Sum(3 DOWNTO 0);
			Neg <= '0';
			Cout <= NOT Sum(4);
			ELSE 
				S <= '0' - Sum(3 DOWNTO 0);
				Neg <= '1';
				Cout <= NOT Sum(4);
				
			END IF;
			end if;
			End PROCESS;
End Behavior;



