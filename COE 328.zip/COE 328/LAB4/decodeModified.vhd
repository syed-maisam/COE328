Library ieee;
USE ieee.std_logic_1164.all;

Entity decodeModified IS 
       Port (w  : IN std_logic_vector(2 DOWNTO 0);
		       En : IN std_logic;
		       y  : out std_logic_vector(0 TO 7));
END decodeModified;

ARCHITECTURE Behavior of decodeModified is 
component decode

port (w: in std_logic_vector (1 downto 0);
		En: in std_logic;
		y: out std_logic_vector (3 downto 0));
		
		end component; 
BEGIN
	dec0: decode port map (w(1 downto 0), not w(2) and En, y(0 to 3));
	dec1: decode port map (w(1 downto 0), En and w(2), y(4 to 7));
	
END Behavior;