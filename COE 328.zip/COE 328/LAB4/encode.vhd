Library ieee;
USE ieee.std_logic_1164.all;

Entity encode IS 
       Port (w  : IN std_logic_vector(3 DOWNTO 0);
		       y  : out std_logic_vector(1 DOWNTO 0);
		       z  : out std_logic);
END encode;

ARCHITECTURE Behavior of encode is 
BEGIN
	PROCESS (w)
	BEGIN 
	    y <= "00";
		 If w(1) = '1' THEN y <= "01"; END If;
		 If w(2) = '1' THEN y <= "10"; END if;
		 If w(3) = '1' THEN y <= "11"; END if;
		 
		 z <= '1';
		 If w = "0000" THEN z <= '0'; END if;
		 END PROCESS;     
END Behavior;