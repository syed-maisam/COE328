Library ieee;
USE ieee.std_logic_1164.all;
Entity mux IS 
       Port (w0, w1, s: IN std_logic;
		 f : out std_logic );
END mux;

ARCHITECTURE Behavior of mux is 
BEGIN 
	WITH s SELECT
	    f<= w0 WHEN '0',
		     w1 WHEN others;

END Behavior;