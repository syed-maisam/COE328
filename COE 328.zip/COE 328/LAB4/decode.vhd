Library ieee;
USE ieee.std_logic_1164.all;

Entity decode IS 
       Port (w  : IN std_logic_vector(1 DOWNTO 0);
		       En : IN std_logic;
		       y  : out std_logic_vector(0 TO 3));
END decode;

ARCHITECTURE Behavior of decode is 
	SIGNAL Enw : std_logic_vector(2 DOWNTO 0);
BEGIN
	Enw <= En & w;
	WITH Enw SELECT
	    y <= "1000" WHEN "100",
		      "0100" WHEN "101",
				"0010" WHEN "110",
				"0001" WHEN "111",
				"0000" WHEN OTHERS;
END Behavior;